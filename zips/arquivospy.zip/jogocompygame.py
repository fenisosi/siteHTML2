import pygame
import random
import sqlite3
from PyQt5 import uic, QtWidgets
import principal
def jogo(v1):
    pygame.init()
    fps = 9
    volume = 0.25

        
    app = QtWidgets.QApplication([])
    final = uic.loadUi("perdeu.ui")


    banco = sqlite3.connect("placar.db")
    c = banco.cursor()

    c.execute("CREATE TABLE IF NOT EXISTS placar (nome TEXT, tempo TEXT, maca TEXT, modo TEXT)")


    pygame.mixer.music.set_volume(volume)
    musicaf = pygame.mixer.music.load("fundo.mp3")
    pygame.mixer.music.play(-1)
    colisao = pygame.mixer.Sound("maca.wav")

    y = random.randint(0, 620)
    x = random.randint(0, 860)
    y_m = random.randint(0, 620)
    x_m = random.randint(0, 860)
    janela = pygame.display.set_mode((880, 640))
    pygame.display.set_caption("pygame game")
    janela.fill((255,255,255))
    velocidade = 7
    velocidade_x = 0
    velocidade_y = 0
    pontos = 0
    ym = 0
    xm = 0
    tempo = 0
    i = 0
    janelaab = 0
    morreu = 1
    lista_cobra = []
    comec = False
    timer = 0
    modo = None
    parece = 0
    font = pygame.font.SysFont("arial black",25)
    font2 = pygame.font.SysFont("arial black",20)
    textof = font.render("aperte 'P' para ver o seu placar e 'R' para jogar novamente",True, (0,0,0))
    relogio = pygame.time.Clock()
    def janelaabe():
        principal.voltardetudo(v1)
        global janelaab, morreu, parece
        janelaab = 0
        morreu = 3
        parece = 1
    def perdeuse(tempon, pontosn):
        global  morreu, i, v1
        c.execute("INSERT INTO placar VALUES('"+str(v1)+"','"+str(tempon)+"','"+str(pontosn)+"','"+str(modo)+"')")
        banco.commit()
        morreu = 2
        c.execute(f"SELECT tempo FROM placar WHERE nome = '{v1}'")
        tempom = c.fetchall()
        c.execute(f"SELECT maca FROM placar WHERE nome = '{v1}'")
        macam = c.fetchall()
        c.execute(f"SELECT modo FROM placar WHERE nome = '{v1}'")
        modom = c.fetchall()
        for it in tempom:
            colocar = f"{v1} seu {i + 1} jogo teve {tempom[0 + i][0]} segundos e {macam[0 + i][0]} pontos no modo {modom[0 + i][0]}!"
            final.widd.addItem(colocar)
            i+=1
    def aumentacobra(lista_cobra):
        for XeY in lista_cobra:
            pygame.draw.rect(janela, (0, 255, 0), (XeY[0], XeY[1], 20, 20))
    def controlacobra(pontos, lista_cobra):
        if len(lista_cobra) > pontos:
            del lista_cobra[0]
    controle = 0
    def morreut():
        global morreu, velocidade, velocidade_x, velocidade_y, pontos,xm,ym,fps, lista_cobra, tempo,timer,controle,i,comec, modo,x,y
        morreu = 2
        velocidade = 10
        velocidade_x = 0
        velocidade_y = 0
        pontos = 0
        ym = 0
        xm = 0
        fps = 10
        lista_cobra = []
        tempo = 0
        timer = 0
        controle = 0
        comec = False
        modo = None
        y = random.randint(0, 620)
        x = random.randint(0, 860)
    while parece == 0:
        while comec == False:
            janela.fill((255,255,255))
            textoo = font2.render("aperte 'C' para começar no modo clasico ou 'i' para começar no modo infinito",False, (0,0,0))
            textooo = font2.render("aperte 'a' para aumentar o volume da musica de fundo ou 'd' para diminuir",False, (0,0,0))
            janela.blit(textoo, (25, 300))
            comandos = pygame.key.get_pressed()
            if comandos[pygame.K_c]:
                janelaab = 2
                comec = True
                modo = "classico"
            if comandos[pygame.K_i]:
                janelaab = 1
                comec = True
                modo = "infinito"
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    comec = True
                    janelaab = 0
                    parece = 1
            pygame.display.update()
        while janelaab == 1:
            pygame.time.delay(50)
            lista_cabeca = []
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    janelaabe()
            comandos = pygame.key.get_pressed()
            if timer < 20:
                timer += 1
            elif timer >= 20:
                tempo += 1
                timer = 0
            if comandos[pygame.K_UP] or comandos[pygame.K_w]:
                if ym != 2: 
                    velocidade_x = 0
                    velocidade_y = -velocidade
                    ym = 1
                    xm = 0
            if comandos[pygame.K_DOWN] or comandos[pygame.K_s]:
                if ym != 1:
                    velocidade_x = 0
                    velocidade_y = velocidade
                    ym = 2
                    xm = 0
            if comandos[pygame.K_RIGHT] or comandos[pygame.K_d]:
                if xm != 2:
                    velocidade_x = velocidade
                    velocidade_y = 0
                    ym = 0
                    xm = 1
            if comandos[pygame.K_LEFT] or comandos[pygame.K_a]:
                if xm != 1:
                    velocidade_x = -velocidade
                    velocidade_y = 0
                    xm = 2
                    ym = 0
            if comandos[pygame.K_o]:
                pontos += 1
            y = y + velocidade_y
            x = x + velocidade_x
            relogio.tick(fps)
            janela.fill((255,255,255))
            maça = pygame.draw.rect(janela, (255, 0, 0), (x_m, y_m, 20, 20))
            lista_cabeca.append(x)
            lista_cabeca.append(y)
            lista_cobra.append(lista_cabeca)
            aumentacobra(lista_cobra)
            textot = font.render(f"tempo: {tempo}",True, (0,0,0))
            textop = font.render(f"maças comidas: {pontos}",True, (0,0,0))
            cobra = pygame.draw.rect(janela, (0, 200, 0), (x, y, 20, 20))
            janela.blit(textot, (0,0))
            janela.blit(textop, (0,30))
            if cobra.colliderect(maça):
                pontos += 1
                colisao.play()
                velocidade += 1
                y_m = random.randint(0, 620)
                x_m = random.randint(0, 860)
            controlacobra(pontos, lista_cobra)
            if lista_cobra.count(lista_cabeca) > 1:
                morreu = 2
            if y >= 640:
                y = 10
            if y <= 0:
                y = 630
            if x >= 870:
                x = 10
            if x <= 0:
                x = 870
            pygame.display.update()
            while morreu == 2:
                pygame.time.delay(50)
                if controle == 0:
                    perdeuse(tempo, pontos)
                    controle = 1
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        janelaabe()
                comandos = pygame.key.get_pressed()
                if comandos[pygame.K_p]:
                    final.show()
                if comandos[pygame.K_r]:
                    morreut()
                    janelaab = 0
                    morreu = 0
                janela.fill((255, 255, 255))
                janela.blit(textof, (40,300))
                pygame.display.update()
        while janelaab == 2:
            pygame.time.delay(50)
            lista_cabeca = []
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    janelaabe()
            comandos = pygame.key.get_pressed()
            if timer < 20:
                timer += 1
            elif timer >= 20:
                tempo += 1
                timer = 0
            if comandos[pygame.K_UP] or comandos[pygame.K_w]:
                if ym != 2: 
                    velocidade_x = 0
                    velocidade_y = -velocidade
                    ym = 1
                    xm = 0
            if comandos[pygame.K_DOWN] or comandos[pygame.K_s]:
                if ym != 1:
                    velocidade_x = 0
                    velocidade_y = velocidade
                    ym = 2
                    xm = 0
            if comandos[pygame.K_RIGHT] or comandos[pygame.K_d]:
                if xm != 2:
                    velocidade_x = velocidade
                    velocidade_y = 0
                    ym = 0
                    xm = 1
            if comandos[pygame.K_LEFT] or comandos[pygame.K_a]:
                if xm != 1:
                    velocidade_x = -velocidade
                    velocidade_y = 0
                    xm = 2
                    ym = 0
            if comandos[pygame.K_o]:
                pontos += 1
            y = y + velocidade_y
            x = x + velocidade_x
            relogio.tick(fps)
            janela.fill((255,255,255))
            maça = pygame.draw.rect(janela, (255, 0, 0), (x_m, y_m, 20, 20))
            lista_cabeca.append(x)
            lista_cabeca.append(y)
            lista_cobra.append(lista_cabeca)
            aumentacobra(lista_cobra)
            textot = font.render(f"tempo: {tempo}",True, (0,0,0))
            textop = font.render(f"maças comidas: {pontos}",True, (0,0,0))
            cobra = pygame.draw.rect(janela, (0, 200, 0), (x, y, 20, 20))
            janela.blit(textot, (0,0))
            janela.blit(textop, (0,30))
            if cobra.colliderect(maça):
                pontos += 1
                colisao.play()
                velocidade += 1
                y_m = random.randint(0, 620)
                x_m = random.randint(0, 860)
            controlacobra(pontos, lista_cobra)
            if lista_cobra.count(lista_cabeca) > 1:
                morreu = 2
            if y >= 640:
                morreu = 2
            if y <= 0:
                morreu = 2
            if x >= 870:
                morreu = 2
            if x <= 0:
                morreu = 2
            pygame.display.update()
            while morreu == 2:
                pygame.time.delay(50)
                if controle == 0:
                    perdeuse(tempo, pontos)
                    controle = 1
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        janelaabe()
                comandos = pygame.key.get_pressed()
                if comandos[pygame.K_p]:
                    final.show()
                if comandos[pygame.K_r]:
                    morreut()
                    morreu = 0
                    janelaab = 0
                janela.fill((255, 255, 255))
                janela.blit(textof, (40,300))
                pygame.display.update()

            


    pygame.quit()